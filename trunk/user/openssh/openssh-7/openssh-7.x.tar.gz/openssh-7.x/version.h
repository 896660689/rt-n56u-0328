/* $OpenBSD: version.h,v 1.83 2018/10/10 16:43:49 deraadt Exp $ */

#define SSH_VERSION	"OpenSSH_7.9"

#define SSH_PORTABLE	"p1"
#define SSH_RELEASE	SSH_VERSION SSH_PORTABLE
